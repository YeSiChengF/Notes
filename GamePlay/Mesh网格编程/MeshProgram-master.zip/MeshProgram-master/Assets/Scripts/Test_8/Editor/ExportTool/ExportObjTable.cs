﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "ExportObjTable",menuName = "CustomTable/Create ExportObjTable")]
public class ExportObjTable : ScriptableObject
{
	public string ExportPath;
}
